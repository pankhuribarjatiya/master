# CPSC-5240-4240
Sample Mocha test

In this repository, you will find the various TDD test cases using mocha:
* Test cases are located in the test directory
* Initialize the pre-requisite modules, including mocha, by running "npm install"
* Run test case using the following command "runningmocha.cmd"

For more details on how to configure and use mocha go to:
http://mochajs.org/

For more details on how to configure chai and chai-http go to:
http://chaijs.com/plugins/chai-http
http://chaijs.com/api/bdd/
