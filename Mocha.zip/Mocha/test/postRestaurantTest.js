var chai = require('chai');
var chaiHttp = require('chai-http');
var async = require('async');

var assert = chai.assert;
var expect = chai.expect;
var should = chai.should();

var http = require('http');
chai.use(chaiHttp);

describe('Post Restaurant result', function () {
    var requestResult;
    var response;

    before(function (done) {
        chai.request("https://eatezf.azurewebsites.net")
            .post("/app/addRestaurant")
            .send({
            restaurantName : "Chick-fil-a",
            restaurantAddress : "112 1st Ave S Ste, Seattle, WA 98104",
            phoneNumber :"+1 2064450999",
            restaurantImageUrl : "https://pbs.twimg.com/profile_images/902984892732014592/S8GzsmFx_400x400.jpg" })
            .end(function (err, res) {
                requestResult = res.body;
                response = res;
                expect(err).to.be.null;
                expect(res).to.have.status(200);
                done();
            });
    });

    
    it('Should return an array of restaurants with all the objects', function (){
        expect(response.body).to.satisfy(
            function (body) {
                for (var i = 0; i < body.length; i++) {
                    expect(body[i]).to.have.property('_id');
                    expect(body[i]).to.have.property('restaurantName');
                    expect(body[i]).to.have.property('restaurantAddress');
                    expect(body[i]).to.have.property('phoneNumber');
                    expect(body[i]).to.have.property('restaurantImageUrl');
                }
                return true;
            });
    });

});
